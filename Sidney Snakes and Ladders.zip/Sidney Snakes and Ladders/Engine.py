import Mechanics

def run():

    while True:                                                                                             #infinite loop to keep replaying game 
        choice = input("Press 1 for NORMAL mode, or, 2 for HARD mode\n(ladders act as snakes):\n")

        while choice != '1' and choice != '2':                                                              #corrects wrong user input 
            print("INVALID INPUT. PLEASE SELECT 1 OR 2:\n")
            choice = input()

        if choice == '1':                                                                                   #runs normal mode
            Mechanics.game()

        elif choice == '2':                                                                                 #runs hard mode 
            Mechanics.HardGame()                                    


